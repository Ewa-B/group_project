# group_project 2022 working in comp industry
